package com.btb.org.restapi;

import javax.ws.rs.CookieParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.Status;

import com.btb.org.model.ErrorMessage;

@Path("/injectdemo")
public class ParamAnnotations {

	@GET
	@Path("/annotations")
	public String getMatrixParam(@MatrixParam("param") String matrixParam,
								@HeaderParam("customHeaderValue") String customHeaderValue,
								@CookieParam("userName") String userName,
								@CookieParam("pass") String pass) {
		return "Matrix Param : "+matrixParam+ " customHeaderValue : "+customHeaderValue + " userName : "+ userName +" Password : "+pass;
	}
	
	@GET
	@Path("/baseurl")
	public String getParamUsingContext(@Context UriInfo uriInfo,@Context HttpHeaders headers) {
		String baseUrl = uriInfo.getAbsolutePath().toString();
		String cookie = headers.getCookies().toString();
		if(cookie!="ravi") {
			ErrorMessage errorMessage = new ErrorMessage("Not Found",404,"http://org.ravi.com/documents/list");
		    Response response = Response.status(Status.NOT_FOUND).entity(errorMessage).build();
			//throw new WebApplicationException(response);
			throw new NotFoundException(response);
		}
		return cookie+" : "+baseUrl;
	}
	
	@Path("/{messageId}/comments")
	public CommentResource getComments(@PathParam("messageId") String messageId) {
		return new CommentResource();
	}
}
