package com.btb.org.restapi;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/")
public class CommentResource {

	@GET
	@Path("/{commentId}")
	public String test(@PathParam("messageId") String messageId, @PathParam("commentId") String commentId) {
		return "Message ID : "+messageId+" :: Comment ID : "+commentId;
	}
	
}
