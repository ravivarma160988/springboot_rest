package com.wipro.kafkasubscribe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaSubscribeApplicationTests {

	@Test
	void contextLoads() {
	}

}
