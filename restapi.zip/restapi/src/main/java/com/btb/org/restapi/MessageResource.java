package com.btb.org.restapi;

import java.net.URI;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import com.btb.org.model.Message;

@Path("/messages")
public class MessageResource {
	
//	@GET
//	@Produces(MediaType.APPLICATION_XML)
//	public Message getMessage() {
//		Message message = new Message(1,"Hi","Welcome to REST API");
//		return message;
//	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Message getMessage() {
		Message message = new Message(1,"Hi","Welcome to REST API");
		return message;
	}
	
	@GET
	@Path("/get")
	@Produces(MediaType.APPLICATION_JSON)
	public Message getMessageById(@QueryParam("id") int id) {
		//Message message = new Message(id,"Hi","Welcome to REST API");
		Message message = new Message(id,"Hi","Welcome to REST API");;
		if(message.getId()==1) {
			throw new DataNotFoundException("Message with "+id+" not found");
		}
		return message;
	}
	
	
	@GET
	@Path("/response")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getMessageResponse(@QueryParam("id") int id) {
		Message message = new Message(id,"Hi","Welcome to REST API");
		return Response.status(Status.CREATED).entity(message).build();
	}
	
	@GET
	@Path("/year")
	@Produces(MediaType.APPLICATION_JSON)
	public Message getMessageByParam(@BeanParam MessageFilterBean filterBean) {
		Message message = new Message(filterBean.getId(),"Hi","Welcome to REST API : "+filterBean.getYear());
		return message;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Message addMessage(Message message) {
		return message;
	}
	
	@POST
	@Path("/add")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addNewMessage(Message message,@Context UriInfo uriInfo) {
	URI uri =uriInfo.getAbsolutePathBuilder().path(String.valueOf(message.getId())).build();
	return	Response.created(uri)
		.entity(message)
		.build();
	}
	
	@DELETE
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public String deleteMessage(@PathParam("id") int id) {
		return "message deleted with id : "+id;
	}
	
	@PUT
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Message updateMessage(@PathParam("id") int id, Message message) {
		return message;
	}
}
