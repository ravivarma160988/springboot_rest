package com.btb.org.restapi;

import javax.ws.rs.QueryParam;

public class MessageFilterBean {
	private @QueryParam("id") int id;
	private @QueryParam("year") int year;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
}
